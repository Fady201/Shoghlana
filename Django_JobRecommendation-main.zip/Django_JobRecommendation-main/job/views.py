from django.db.models import Q
from django.forms import model_to_dict
from django.http import JsonResponse
from django.shortcuts import render, redirect

from account.models import User, Company, JobSeeker
from .models import Job, Application, Saved_Jobs
from django.db.models import Count


# Create your views here.
def all_jobs(request):
    user = User.objects.get(pk=request.user.pk)
    if user.user_type == 'Company':
        redirect("company_profile")
    user = JobSeeker.objects.get(user=user)
    jobs = Job.objects.filter(Q(ml_title=user.ml_title)
                              | Q(title__icontains=user.target_job)).order_by(
        '-created_at')
    return render(request, "pages/alljob.html", {"jobs": jobs, "is_auth": request.user.is_authenticated, "user": user})


def add_job(request):
    company = Company.objects.get(user=request.user)
    job = Job(
        Company_ID=company,
        title=request.POST.get("title"),
        description=request.POST.get("description"),
        location=request.POST.get("location"),
        industry=request.POST.get("industry"),
        exp=int(request.POST.get("exp")),
        salary=float(request.POST.get("salary")),
        expires_date=request.POST.get("expires_date"),
        employment_type=request.POST.get("employment_type"),
        seniority_level=request.POST.get("seniority_level"),
        education=request.POST.get("education"),
        field_of_study=request.POST.get("field_of_study"),
        skills=request.POST.get("skills"),
        languages=request.POST.get("languages"),
        graduation_year=request.POST.get("graduation_year"),
    )
    job.save()
    return redirect("company_profile")


def delete_job(request, job_id):
    if request.user is not None and request.user.is_authenticated:
        company = Company.objects.get(user=request.user)
        if company is not None:
            Job.objects.get(job_ID=job_id).delete()
    return redirect("company_profile")


def edit_job(request):
    if request.user is not None and request.user.is_authenticated:
        user = User.objects.get(pk=request.user.pk)
        company = Company.objects.get(user=user)
        if company is not None:
            Job.objects.filter(job_ID=request.POST.get("job_id")).update(
                title=request.POST.get("title"),
                description=request.POST.get("description"),
                location=request.POST.get("location"),
                industry=request.POST.get("industry"),
                exp=request.POST.get("exp"),
                salary=request.POST.get("salary"),
                expires_date=request.POST.get("expires_date"),
                employment_type=request.POST.get("employment_type"),
                seniority_level=request.POST.get("seniority_level")
            )
    return redirect("company_profile")


def get_job(request, job_id):
    if request.user is not None and request.user.is_authenticated:
        try:
            company = Company.objects.get(user=request.user)
            if company is not None:
                job = Job.objects.get(job_ID=job_id)
                job_data = model_to_dict(job)
                return JsonResponse({'e_job': job_data})
        except Company.DoesNotExist:
            return JsonResponse({'error': 'Company not found'}, status=404)
        except Job.DoesNotExist:
            return JsonResponse({'error': 'Job not found'}, status=404)
    return JsonResponse({'error': 'User not authenticated'}, status=401)


def search_jobs(request):
    if request.method == "POST":
        is_auth = False
        user = None
        if request.user is not None and request.user.is_authenticated:
            is_auth = True
            user = User.objects.get(pk=request.user.pk)
            user = JobSeeker.objects.get(user=user)
            jobs = Job.objects.filter(Q(title__contains=request.POST.get('searchKeyword')) | Q(
                description__contains=request.POST.get('searchKeyword'))).order_by('-created_at')
        else:
            return redirect("login_user")
        return render(request, "pages/alljob.html", {"jobs": jobs, "is_auth": is_auth, "user": user})
    else:
        return redirect("all_jobs")


def get_job_details(request, job_id):
    job = Job.objects.get(job_ID=job_id)
    company = Company.objects.get(user=job.Company_ID.user)
    is_auth = request.user.is_authenticated
    user = JobSeeker.objects.get(user=request.user)
    recommended_jobs = Job.objects.filter(
        (Q(ml_title=user.ml_title) | Q(title__icontains=user.target_job)) & ~Q(job_ID=job_id)).order_by('-created_at')
    return render(request, "pages/job-details-pages/job-details.html",
                  {"job": job, "company": company, "is_auth": is_auth, "user": user,
                   "recommended_jobs": recommended_jobs})


def apply_for_job(request, job_id):
    if request.user is not None and request.user.is_authenticated:
        user = JobSeeker.objects.get(pk=request.user.pk)
        company = Company.objects.get(pk=request.POST.get("company_id"))
        if user.user.user_type == 'jobSeeker':
            Application.objects.create(Job_ID=Job.objects.get(job_ID=job_id),
                                       JobSeeker_id=user,
                                       Company_ID=company)
    return redirect("all_jobs")


def freelancer_jobs(request):
    user = User.objects.get(pk=request.user.pk)
    jobSeeker = JobSeeker.objects.get(user=user)
    jobs = Job.objects.filter(employment_type='Contract').order_by('-created_at')
    return render(request, "pages/freelance.html",
                  {"jobs": jobs, "is_auth": request.user.is_authenticated, "user": jobSeeker})


def common_jobs(request):
    jobs = Job.objects.annotate(application_count=Count('application')).order_by('-application_count')
    return render(request, "pages/common-jobs/common-jobs.html",
                  {"jobs": jobs, "is_auth": request.user.is_authenticated})


def save_job(request, job_id):
    if request.user is not None and request.user.is_authenticated:
        user = JobSeeker.objects.get(pk=request.user.pk)
        company = Company.objects.get(pk=Job.objects.get(job_ID=job_id).Company_ID.pk)
        if user.user.user_type == 'jobSeeker':
            if Saved_Jobs.objects.filter(Job_ID=Job.objects.get(job_ID=job_id),
                                         JobSeeker_id=user,
                                         Company_ID=company).exists():
                return redirect("all_jobs")
            Saved_Jobs.objects.create(Job_ID=Job.objects.get(job_ID=job_id),
                                      JobSeeker_id=user,
                                      Company_ID=company)
    return redirect("all_jobs")
