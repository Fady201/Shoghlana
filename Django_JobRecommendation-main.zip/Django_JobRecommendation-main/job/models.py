import requests
from django.db import models
from account.models import Company, JobSeeker


class Job(models.Model):
    EMPLOYMENT_TYPE_CHOICES = [
        ('Full-time', 'دوام كامل'),
        ('Part-time', 'دوام جزئي'),
        ('Contract', 'عقد'),
        ('Temporary', 'مؤقت'),
        ('Internship', 'تدريب'),
    ]

    SENIORITY_LEVEL_CHOICES = [
        ('Entry', 'مبتدئ'),
        ('Mid', 'متوسط'),
        ('Senior', 'محترف'),
        ('Executive', 'تنفيذي'),
    ]

    job_ID = models.AutoField(primary_key=True)
    Company_ID = models.ForeignKey(Company, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    description = models.TextField()
    location = models.CharField(max_length=255)
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    employment_type = models.CharField(max_length=10, choices=EMPLOYMENT_TYPE_CHOICES)
    seniority_level = models.CharField(max_length=10, choices=SENIORITY_LEVEL_CHOICES)
    exp = models.IntegerField()
    industry = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    expires_date = models.DateField()
    ml_title = models.CharField(max_length=255, null=True, blank=True)
    education = models.CharField(max_length=255,
                                 choices=[('High School', 'دبلومة'), ('Bachelor', 'بكالوريس'), ('Master', 'ماجستير'),
                                          ('PhD', 'دكتوراه')])
    field_of_study = models.CharField(max_length=255)
    skills = models.TextField()
    languages = models.TextField()
    graduation_year = models.DateField()

    def get_ml_title(self):
        api_url = "https://api-inference.huggingface.co/models/Helsinki-NLP/opus-mt-ar-en"
        headers = {"Authorization": "Bearer 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"}

        def query(payload):
            response = requests.post(api_url, headers=headers, json=payload)
            return response.json()

        output = query({
            "inputs": self.description,
        })
        output = output[0].get("translation_text")
        api_url = "https://api-inference.huggingface.co/models/syedroshanzameer/resume_model"

        def job_query(payload):
            response = requests.post(api_url, headers=headers, json=payload)
            return response.json()

        job = job_query({
            "inputs": output,
        })
        for i in range(1000):
            pass
        job = job[0]
        job = job[0]
        job = job.get("label")
        return job

    def save(self, *args, **kwargs):
        self.ml_title = self.get_ml_title()
        super(Job, self).save(*args, **kwargs)

    def __str__(self):
        return self.title


class Application(models.Model):
    statusChoices = [
        ('Pending', 'قبد المراجعة'),
        ('Accepted', 'مقبول'),
        ('Rejected', 'مرفوض'),
    ]
    Application_ID = models.AutoField(primary_key=True)
    Job_ID = models.ForeignKey(Job, on_delete=models.CASCADE)
    JobSeeker_id = models.ForeignKey(JobSeeker, on_delete=models.CASCADE)
    Company_ID = models.ForeignKey(Company, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=255, default="Pending", choices=statusChoices)


class Saved_Jobs(models.Model):
    saved_ID = models.AutoField(primary_key=True)
    Job_ID = models.ForeignKey(Job, on_delete=models.CASCADE)
    JobSeeker_id = models.ForeignKey(JobSeeker, on_delete=models.CASCADE)
    Company_ID = models.ForeignKey(Company, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
