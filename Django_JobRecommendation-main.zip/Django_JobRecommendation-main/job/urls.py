from django.urls import path

from account.views import accept_application, reject_application
from .views import all_jobs, add_job, delete_job, edit_job, get_job, search_jobs, get_job_details, apply_for_job, \
    freelancer_jobs, common_jobs, save_job

urlpatterns = [
    path('', all_jobs, name='all_jobs'),
    path('add_job/', add_job, name='add_job'),
    path('delete-job/<int:job_id>/', delete_job, name='delete_job'),
    path('edit-job/', edit_job, name='edit_job'),
    path('get-job/<int:job_id>/', get_job, name='get_job'),
    path('get-job-details/<int:job_id>/', get_job_details, name='get_job_details'),
    path('search_job/', search_jobs, name='search_job'),
    path('apply-job/<int:job_id>/', apply_for_job, name='apply_for_job'),
    path('accept-job/<int:application_id>/', accept_application, name='accept_application'),
    path('reject-job/<int:application_id>/', reject_application, name='reject_application'),
    path('freelancer-jobs/', freelancer_jobs, name='freelancer_jobs'),
    path("common-jobs/", common_jobs, name="common_jobs"),
    path("save-job/<int:job_id>/", save_job, name="save_job"),
]
