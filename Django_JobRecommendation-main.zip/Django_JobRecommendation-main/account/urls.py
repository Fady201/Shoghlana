from django.urls import path
from .views import login_company, register_company, login_user, register_user, logout_user, company_profile, \
    user_profile, update_company_info, update_user_info, user_profile_view, admin_profile
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('login-user/', login_user, name='login_user'),
    path('register-user/', register_user, name='register_user'),
    path('login-company/', login_company, name='login_company'),
    path('register-company/', register_company, name='register_company'),
    path('company-profile/', company_profile, name='company_profile'),
    path('user-profile/', user_profile, name='user_profile'),
    path('logout/', logout_user, name='logout'),
    path('update-company/', update_company_info, name='update-company-info'),
    path('password-reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password-reset-done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    path('update-user-info', update_user_info, name='update_user_info'),
    path('user-profile-view/<int:user_id>', user_profile_view,name='user_profile_view'),
    path('admin-profile', admin_profile, name='admin_profile')
]



