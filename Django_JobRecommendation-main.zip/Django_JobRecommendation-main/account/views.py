from datetime import date

from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate

from job.models import Job, Application, Saved_Jobs
from .forms import UserRegisterForm, JobSeekerRegisterForm, CompanyRegisterForm, UserLoginForm
from .models import User, JobSeeker, Company


def register_user(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        user_form = UserRegisterForm(request.POST)
        job_seeker_form = JobSeekerRegisterForm(request.POST, request.FILES)
        if user_form.is_valid() and job_seeker_form.is_valid():
            user = user_form.save(commit=False)
            user.set_password(user_form.cleaned_data['password'])
            user.save()
            job_seeker = job_seeker_form.save(commit=False)
            job_seeker.user = user
            job_seeker.save()
            login(request, user)
            return redirect('home')
    else:
        user_form = UserRegisterForm()
        job_seeker_form = JobSeekerRegisterForm()
    return render(request, 'pages/auth/register-user.html', {
        'user_form': user_form,
        'job_seeker_form': job_seeker_form
    })


def register_company(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        user_form = UserRegisterForm(request.POST)
        company_form = CompanyRegisterForm(request.POST, request.FILES)
        if user_form.is_valid() and company_form.is_valid():
            user = user_form.save(commit=False)
            user.set_password(user_form.cleaned_data['password'])
            user.save()
            company = company_form.save(commit=False)
            company.user = user
            company.save()
            login(request, user)
            return redirect('home')
    else:
        user_form = UserRegisterForm()
        company_form = CompanyRegisterForm()
    return render(request, 'pages/auth/register-company.html', {
        'user_form': user_form,
        'company_form': company_form
    })


def login_user(request):
    if request.user.is_authenticated:
        return redirect('home')
    error = False
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                error = True
    else:
        form = UserLoginForm()
    return render(request, 'pages/auth/login-user.html', {'user_login_form': form, 'error': error})


def login_company(request):
    if request.user.is_authenticated:
        return redirect('home')
    error = False
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                error = True
    else:
        form = UserLoginForm()
    return render(request, 'pages/auth/login-company.html', {'company_login_form': form, 'error': error})


def logout_user(request):
    logout(request)
    return redirect('home')


def company_profile(request):
    user = None
    if request.user is not None and request.user.is_authenticated:
        user = User.objects.get(pk=request.user.pk)
        company = Company.objects.get(user=user)
        company_jobs = Job.objects.filter(Company_ID=company).order_by('-created_at')
        applications = Application.objects.select_related('Job', 'jobSeeker') \
            .values('Job_ID__title', 'Job_ID__location', 'Job_ID__exp', 'JobSeeker_id__image', 'JobSeeker_id',
                    'JobSeeker_id__F_name', 'JobSeeker_id__L_name', 'Job_ID__salary', "status", 'Application_ID') \
            .filter(Company_ID=company).order_by("-created_at").all()
    else:
        return redirect("home")
    return render(request, "pages/company-profile.html",
                  {'user': company, 'company_jobs': company_jobs, 'applications': applications})


def update_company_info(request):
    if request.method == "POST":
        if request.POST.get('password') is not None:
            password = request.POST.get('password')
            user = Company.objects.get(user=request.user)
            user.user.set_password(password)
        Company.objects.filter(user=request.user).update(
            title=request.POST.get('title'),
            phone=request.POST.get('phone'),
            website=request.POST.get('website'),
            industry=request.POST.get('industry'),
            tax_card=request.POST.get('tax_card'),
            commercial_register=request.POST.get('commercial_register')
        )
    return redirect("company_profile")


def user_profile(request):
    user = None
    if request.user is not None and request.user.is_authenticated:
        user = User.objects.get(pk=request.user.pk)
        jobSeeker = JobSeeker.objects.get(user=user)
        if jobSeeker.dob is not None and jobSeeker.graduation_year is not None:
            jobSeeker.dob = jobSeeker.dob.strftime('%Y-%m-%d')
            jobSeeker.graduation_year = jobSeeker.graduation_year.strftime('%Y-%m-%d')
        applications = Application.objects.select_related('Job', 'Company') \
            .values('Job_ID__title', 'Job_ID__location', 'Job_ID__exp', 'Company_ID__title', 'Company_ID',
                    'Company_ID__title', 'Company_ID__logo', 'Job_ID__salary', "status", 'Application_ID') \
            .filter(JobSeeker_id=jobSeeker).order_by("-created_at").all()
        saved_jobs = Saved_Jobs.objects.select_related('Job', 'Company') \
            .values('Job_ID__title', 'Job_ID__location', 'Job_ID__exp', 'Company_ID__title', 'Company_ID',
                    'Company_ID__title', 'Company_ID__logo', 'Job_ID__salary', 'saved_ID') \
            .filter(JobSeeker_id=jobSeeker).order_by("-created_at").all()
        print(saved_jobs)
    else:
        return redirect("home")
    return render(request, "pages/user-profile-edit.html", {'jobSeeker': jobSeeker, 'applications': applications,
                                                            'saved_jobs': saved_jobs})


def update_user_info(request):
    if request.method == "POST":
        if request.POST.get('password') is not None:
            password = request.POST.get('password')
            user = JobSeeker.objects.get(user=request.user)
            user.user.set_password(password)
        today = date.today()
        if request.FILES.get('image') is not None:
            JobSeeker.objects.filter(user=request.user).update(
                image=request.FILES.get('image')
            )
        JobSeeker.objects.filter(user=request.user).update(
            F_name=request.POST.get('F_name'),
            L_name=request.POST.get('L_name'),
            phone=request.POST.get('phone'),
            dob=request.POST.get('dob'),
            age=today.year - int(request.POST.get('dob').split('-')[0]),
            exp=request.POST.get('exp'),
            target_job=request.POST.get('t_job'),
            languages=request.POST.get('languages'),
            skills=request.POST.get('skills'),
            address=request.POST.get('address'),
            gender=request.POST.get('gender'),
            education=request.POST.get('education'),
            field_of_study=request.POST.get('field_of_study'),
            university=request.POST.get('university'),
            gpa=float(request.POST.get('gpa').replace(',', '.')),
            summary=request.POST.get('summary'),
            graduation_year=request.POST.get('graduation_year'),
        )
    return redirect("user_profile")


def user_profile_view(request, user_id):
    user = User.objects.get(pk=user_id)
    jobSeeker = JobSeeker.objects.get(user=user)
    return render(request, "pages/view-user-profile/view-user-profile.html", {'jobSeeker': jobSeeker})


def accept_application(request, application_id):
    Application.objects.filter(Application_ID=application_id).update(status="Accepted")
    return redirect("company_profile")


def reject_application(request, application_id):
    Application.objects.filter(Application_ID=application_id).update(status="Rejected")
    return redirect("company_profile")


def admin_profile(request):
    return render(request, "pages/admin/admin-permission.html")
