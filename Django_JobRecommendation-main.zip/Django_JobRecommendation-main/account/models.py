from datetime import date

from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.utils.translation import gettext_lazy as _
import requests


class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError(_('The Email field must be set'))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('user_type', 'admin')

        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser must have is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser must have is_superuser=True.'))

        return self.create_user(email, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    USER_TYPE_CHOICES = (
        ('admin', 'Admin'),
        ('company', 'Company'),
        ('jobSeeker', 'JobSeeker'),
    )

    email = models.EmailField(_('email address'), unique=True)
    user_type = models.CharField(max_length=10, choices=USER_TYPE_CHOICES)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(auto_now_add=True)
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='custom_user_set',
        blank=True,
        help_text=_(
            'The groups this user belongs to. A user will get all permissions granted to each of their groups.'),
        verbose_name=_('groups'),
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='custom_user_set',
        blank=True,
        help_text=_('Specific permissions for this user.'),
        verbose_name=_('user permissions'),
    )

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    def __str__(self):
        return self.email



class Company(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    title = models.CharField(max_length=255)
    industry = models.CharField(max_length=255)
    phone = models.CharField(max_length=20)
    website = models.URLField()
    location = models.CharField(max_length=255)
    description = models.TextField()
    logo = models.ImageField(upload_to='company_logos/', blank=True, null=True)
    tax_card = models.CharField(max_length=255)
    commercial_register = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        self.user.user_type = "company"
        self.user.save()
        super(Company, self).save(*args, **kwargs)


class JobSeeker(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    F_name = models.CharField(max_length=255)
    L_name = models.CharField(max_length=255)
    phone = models.CharField(max_length=20)
    dob = models.DateField(blank=True, null=True)
    age = models.IntegerField(blank=True, null=True)
    gender = models.CharField(max_length=10, choices=[('M', 'ذكر'), ('F', 'أنثى')])
    image = models.ImageField(upload_to='job_seeker_images/', blank=False, null=False)
    exp = models.IntegerField()
    target_job = models.CharField(max_length=255, null=True, blank=True)
    summary = models.TextField()
    ml_title = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    education = models.CharField(max_length=255, choices=[('High School', 'دبلومة'), ('Bachelor', 'بكالوريس'), ('Master', 'ماجستير'), ('PhD', 'دكتوراه')], null=True, blank=True)
    field_of_study = models.CharField(max_length=255, null=True, blank=True)
    university = models.CharField(max_length=255, null=True, blank=True)
    gpa = models.FloatField(null=True, blank=True)
    skills = models.TextField(null=True, blank=True)
    languages = models.TextField(null=True, blank=True)
    address = models.CharField(max_length=255)
    graduation_year = models.DateField(null=True, blank=True)

    def get_ml_title(self):
        api_url = "https://api-inference.huggingface.co/models/Helsinki-NLP/opus-mt-ar-en"
        headers = {"Authorization": "Bearer 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"}

        def query(payload):
            response = requests.post(api_url, headers=headers, json=payload)
            return response.json()

        output = query({
            "inputs": self.summary,
        })
        output = output[0].get("translation_text")
        api_url = "https://api-inference.huggingface.co/models/syedroshanzameer/resume_model"

        def job_query(payload):
            response = requests.post(api_url, headers=headers, json=payload)
            return response.json()


        job = job_query({
            "inputs": output,
        })
        for i in range(1000):
            pass
        job = job[0]
        job = job[0]
        job = job.get("label")
        return job

    def calculate_age(self):
        today = date.today()
        return today.year - self.dob.year - ((today.month, today.day) < (self.dob.month, self.dob.day))

    def save(self, *args, **kwargs):
        self.ml_title = self.get_ml_title()
        self.age = self.calculate_age()
        self.user.user_type = "jobSeeker"
        self.user.save()
        super(JobSeeker, self).save(*args, **kwargs)

    def __str__(self):
        return f'{self.F_name} {self.L_name}'
