# forms.py
from django import forms
from .models import User, JobSeeker, Company


class UserRegisterForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['email', 'password']
        labels = {
            'email': 'البريد الإلكتروني',
            'password': 'كلمة المرور',
        }
        widgets = {
            'email': forms.EmailInput(attrs={'placeholder': 'البريد الإلكتروني', 'class': 'form-control'}),
            'password': forms.PasswordInput(attrs={'placeholder': 'كلمة المرور', 'class': 'form-control',
                                                   'style': 'direction:ltr;text-align:right;'}),
        }


class JobSeekerRegisterForm(forms.ModelForm):
    class Meta:
        model = JobSeeker
        fields = ['F_name', 'L_name', 'phone', 'dob', 'gender', 'image', 'exp', 'target_job', 'summary']
        labels = {
            'F_name': 'الاسم الأول',
            'L_name': 'الاسم الأخير',
            'phone': 'رقم الهاتف',
            'dob': 'تاريخ الميلاد',
            'gender': 'النوع',
            'image': 'الصورة',
            'exp': 'عدد سنوات الخبرة',
            'target_job': 'الوظيفة المستهدفة',
            'summary': 'ملخص السيرة الذاتية',
        }
        widgets = {
            'F_name': forms.TextInput(attrs={'placeholder': 'الاسم الأول', 'class': 'form-control'}),
            'L_name': forms.TextInput(attrs={'placeholder': 'الاسم الأخير', 'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'placeholder': 'رقم الهاتف', 'class': 'form-control'}),
            'dob': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'gender': forms.Select(attrs={'class': 'form-control'}),
            'image': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'exp': forms.NumberInput(attrs={'placeholder': 'عدد سنوات الخبرة', 'class': 'form-control'}),
            'target_job': forms.TextInput(attrs={'placeholder': 'الوظيفة المستهدفة', 'class': 'form-control'}),
            'summary': forms.Textarea(attrs={'placeholder': 'ملخص السيرة الذاتية', 'class': 'form-control'}),
        }


class CompanyRegisterForm(forms.ModelForm):
    class Meta:
        model = Company
        fields = ['title', 'description', 'location','tax_card', 'commercial_register', 'industry', 'phone', 'website', 'logo']
        labels = {
            'title': 'اسم الشركة',
            'description': 'وصف الشركة',
            'location': 'فروع الشركة',
            'tax_card': 'البطاقة الضريبية',
            'commercial_register': 'السجل التجاري',
            'industry': 'الصناعة',
            'phone': 'رقم الهاتف',
            'website': 'الموقع الإلكتروني',
            'logo': 'الشعار',
        }
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'اسم الشركة', 'class': 'form-control'}),
            'description': forms.Textarea(attrs={'placeholder': 'وصف الشركة', 'class': 'form-control'}),
            'location': forms.Textarea(attrs={'placeholder': 'فروع الشركة', 'class': 'form-control'}),
            'tax_card': forms.TextInput(attrs={'placeholder': 'البطاقة الضريبية', 'class': 'form-control'}),
            'commercial_register': forms.TextInput(attrs={'placeholder': 'السجل التجاري', 'class': 'form-control'}),
            'industry': forms.TextInput(attrs={'placeholder': 'الصناعة', 'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'placeholder': 'رقم الهاتف', 'class': 'form-control'}),
            'website': forms.URLInput(attrs={'placeholder': 'الموقع الإلكتروني', 'class': 'form-control'}),
            'logo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }


class UserLoginForm(forms.Form):
    email = forms.EmailField(
        label='البريد الإلكتروني',
        widget=forms.EmailInput(attrs={'placeholder': 'البريد الإلكتروني', 'class': 'form-control'})
    )
    password = forms.CharField(
        label='كلمة المرور',
        widget=forms.PasswordInput(attrs={'placeholder': 'كلمة المرور', 'class': 'form-control'})
    )
