// let file = document.getElementById("file");
// let img = document.getElementById("img");
// let img2 = document.getElementById("img2");
//
// file.addEventListener("change", function (event) {
//   const fileInput = event.target;
//   if (fileInput.files && fileInput.files[0]) {
//     const reader = new FileReader();
//     reader.onload = function (e) {
//       img.src = e.target.result;
//       img2.src = e.target.result;
//     };
//     reader.readAsDataURL(fileInput.files[0]);
//   }
// });
//
// // ===========================================================
// // let name = document.getElementById("name");
// // let age = document.getElementById("age");
// // let skill = document.getElementById("skill");
// // let email = document.getElementById("email");
// // let number = document.getElementById("number");
// // let country = document.getElementById("country");
// // let password = document.getElementById("password");
// // let collage = document.getElementById("collage");
// // let year = document.getElementById("year");
// // let area = document.getElementById("area");
// // let job = document.getElementById("job");
// // let lastjob = document.getElementById("lastjob");
// // let type = document.getElementById("type");
// // let type2 = document.getElementById("type2");
// // let salary = document.getElementById("salary");
//
// let btn1 = document.getElementById("btn1");
// let btn2 = document.getElementById("btn2");
// let btn3 = document.getElementById("btn3");
// let row = document.getElementById("row");
//
