let jobCards = document.getElementsByClassName("card");
let cards = ``;
for (var i = 0; i <= jobCards.length; i++) {
  jobCards[i].addEventListener("click", function () {
    cards = ``;
    document.getElementById("row").innerHTML = cards;
    setTimeout(function () {
      for (let j = 0; j < 10; j++) {
        cards += `
    <div class="col" id="webjob">
    <div class="card">
      <div class="card-body text-end">
        <div class="over">
          <button class="logo2">
            <i class="fa-solid fa-share-nodes"></i>
          </button>
          <button class="logo2">
          <i class="fa-regular fa-bookmark"></i></button
          ><br />
           <p class="star">
            <i class="fa-solid fa-star"></i>
            <i class="fa-solid fa-star"></i>
            <i class="fa-solid fa-star"></i>
            <i class="fa-solid fa-star"></i>
            <i class="fa-regular fa-star"></i>
          </p> 
        </div>
        <h2 class="card-title">مدير عام</h2>
        <p class="card-p">اسم الشركة - القاهرة، وسط البلد</p>
        <p class="card-text">الراتب الاساسي</p>
        <p class="card-text">نوع الدوام</p>
        <p class="card-text">متطلبات الوظيفه</p>
        <div class="card-btn">
          <a href="#" class="btn btn-primary">تقديم</a>
        </div>
      </div>
    </div>
  </div>
        `;
      }

      document.getElementById("row").innerHTML = cards;
    }, 300);
  });
}
