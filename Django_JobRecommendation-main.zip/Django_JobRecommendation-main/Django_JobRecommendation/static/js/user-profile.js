const sections = {
    'btn1': 'personInfo',
    'btn2': 'request-applications',
    'btn3': 'saved-jobs'
};

const showSection = (e) => {
    // Hide all sections
    for (let id in sections) {
        document.getElementById(sections[id]).style.display = 'none';
    }

    // Show the clicked section
    document.getElementById(sections[e.target.id]).style.display = 'flex';

    // Handle active button
    const activeButton = document.querySelector('button.active');
    if (activeButton) {
        activeButton.classList.remove('active');
    }
    e.target.classList.add('active');
}

document.addEventListener('DOMContentLoaded', ()=> {
    // Hide all sections initially
    for (let id in sections) {
        document.getElementById(sections[id]).style.display = 'none';
    }

    // Show the first section
    document.getElementById(sections['btn1']).style.display = 'flex';

    // Add event listeners to buttons
    for (let id in sections) {
        document.getElementById(id).addEventListener('click', showSection);
    }
});