const companyInfo = document.querySelector("#company-info");
const addJob = document.querySelector("#add-job");
const currJob = document.querySelector("#all-current-jobs");
const applications = document.querySelector("#applicationRequests");
const btn0 = document.querySelector("#btn0");
const btn1 = document.querySelector("#btn1");
const btn2 = document.querySelector("#btn2");
const btn3 = document.querySelector("#btn3");
const buttons = [btn0,btn1,btn2,btn3];
const sections = [companyInfo,addJob,currJob,applications];
const title = document.getElementById('title');
const industry = document.getElementById('industry');
const c_location = document.getElementById('location');
const exp = document.getElementById('exp');
const salary = document.getElementById('salary');
const employment_type = document.getElementById('employment_type');
const seniority_level = document.getElementById('seniority_level');
const description = document.getElementById('description');
const expires_date = document.getElementById('expires_date');
const modalTitle = document.querySelector("h1.modal-title");
const modal = document.getElementById('exampleModal');
const jobID = document.getElementById("job-id");

function activeClassFun(btn) {
    buttons.forEach(button=>{
        if (button !== btn){
            button.classList.remove("active");
        }
    });
    btn.classList.add("active");
}

function showAndHide(sec) {
    sections.forEach(section=>{
        if (sec !== section)
            section.style.display="none";
    })
    sec.style.display="block";
}



function blurBody() {
    if (!modal) return; // Ensure modal is defined
    modal.classList.add('show');
    modal.style.display = 'block';
    document.body.classList.add('modal-open');
    document.body.classList.add('body-blur'); // Add body blur class
    document.body.classList.add("overflow-hidden") // Disable body overflow
    modal.addEventListener('click', showBody);
    document.querySelector("button.btn-close").addEventListener("click", showBody);
    document.getElementById("close-btn").addEventListener("click", showBody); // Correct selector
}

function showBody(e) {
    if (e.target === modal || e.target.classList.contains('btn-close') || e.target.id === 'close-btn') {
        modal.classList.remove('show');
        modal.style.display = 'none';
        document.body.classList.remove('modal-open');
        document.body.classList.remove('body-blur'); // Remove body blur class
        document.body.classList.remove("overflow-hidden"); // Enable body overflow
        modal.removeEventListener('click', showBody);
        document.querySelector("button.btn-close").removeEventListener("click", showBody);
        document.getElementById("close-btn").removeEventListener("click", showBody); // Correct selector
    }
}

// Trigger the blur effect when modal is shown
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('exampleModal').addEventListener('show.bs.modal', blurBody);
});

function get_job(job_id) {
    blurBody();
    fetch(`http://localhost:8000/job/get-job/${job_id}/`, {
        method: 'GET',
        credentials: 'include'  // include cookies in the request if needed for authentication
    })
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then((data) => {
            if (data.error) {
                console.error(data.error);
            } else {
                //logic here
                const {e_job} =data;
                jobID.value = job_id;
                title.value = modalTitle.textContent = e_job['title']
                industry.value = e_job['industry']
                c_location.value = e_job['location']
                exp.value = e_job['exp']
                salary.value = e_job['salary']
                employment_type.value = e_job['employment_type']
                seniority_level.value = e_job['seniority_level']
                description.value = e_job['description']
                expires_date.value = e_job['expires_date']
            }
        })
        .catch((error) => {
            console.error('There was a problem with the fetch operation:', error);
        });
}




document.addEventListener("DOMContentLoaded",()=>{
    addJob.style.display = "none";
    currJob.style.display = "none";
    applications.style.display = "none";
    buttons.forEach(button=>{
        button.addEventListener("click",(event)=>{
            activeClassFun(button);
            if (button.textContent.includes("الملف الشخصي")){
                showAndHide(companyInfo);
            }else if (button.textContent.includes("اضافة وظيفة")){
                showAndHide(addJob);
            }else if (button.textContent.includes("الوظائف الحالية")){
                showAndHide(currJob);
            }else if (button.textContent.includes("طلبات التقديم")){
                showAndHide(applications);
            }
        })
    });
});



