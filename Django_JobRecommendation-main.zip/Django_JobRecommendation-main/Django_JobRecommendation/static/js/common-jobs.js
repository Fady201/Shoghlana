function resetColor() {
  dataAnalytics.style.backgroundColor =''
  dataAnalytics.style.color =''

  accounting.style.backgroundColor =''
  accounting.style.color =''

  UiUx.style.backgroundColor =''
  UiUx.style.color =''

  customerService.style.backgroundColor =''
  customerService.style.color =''

  management.style.backgroundColor =''
  management.style.color =''

  iti.style.backgroundColor =''
  iti.style.color =''

  more.style.backgroundColor =''
  more.style.color =''


}



let cards_trend=document.querySelector('.cards-trend')
let cards_trend_content

// محلل بيانات
let dataAnalytics=document.getElementById('dataAnalytics')
dataAnalytics.addEventListener('click',function(){

  resetColor()
  cards_trend_content=``
    dataAnalytics.style.backgroundColor='#DBF6E6'
    dataAnalytics.style.color='#0D363B'
    for (let i = 0; i < 3; i++) {
        cards_trend_content+=`
        <div class="cards-trend-card">
        <h1>محلل بيانات</h1>
        <p><i class="fas fa-building-flag"></i> اسم الشركة:  <span> المقاولون العرب</span></p>
        <p><i class="fas fa-location-dot"></i> موقع الشركة:  <span>  القاهرة، مدينة نصر</span></p>
        <p><i class="fas fa-money-bill-1-wave"></i> الراتب الاساسي:  <span>  8000 ج/م</span></p>
        <p><i class="fas fa-cubes"></i> نوع الوظيفة:  <span>  يومين عطلة كل اسبوع</span></p>
        <img src="./logo/SVGRepo_iconCarrier.svg" alt="">
        <button>تقديم</button>
        <div class="icons">
          <i class="fas fa-share-nodes"></i>
          <i class="fas fa-bookmark"></i>
        </div>
      
        </div>
    `
        
        
    }
    cards_trend.innerHTML=cards_trend_content
})

// محاسبة
let accounting=document.getElementById('accounting')
accounting.addEventListener('click',function(){
  resetColor()
  cards_trend_content=``
  accounting.style.backgroundColor='#DBF6E6'
    accounting.style.color='#0D363B'
    for (let i = 0; i < 3; i++) {
        cards_trend_content+=`
        <div class="cards-trend-card">
        <h1>محاسبة</h1>
        <p><i class="fas fa-building-flag"></i> اسم الشركة:  <span> المقاولون العرب</span></p>
        <p><i class="fas fa-location-dot"></i> موقع الشركة:  <span>  القاهرة، مدينة نصر</span></p>
        <p><i class="fas fa-money-bill-1-wave"></i> الراتب الاساسي:  <span>  8000 ج/م</span></p>
        <p><i class="fas fa-cubes"></i> نوع الوظيفة:  <span>  يومين عطلة كل اسبوع</span></p>
        <img src="./logo/SVGRepo_iconCarrier.svg" alt="">
        <button>تقديم</button>
        <div class="icons">
          <i class="fas fa-share-nodes"></i>
          <i class="fas fa-bookmark"></i>
        </div>
      
        </div>
    `
        
        
    }
    cards_trend.innerHTML=cards_trend_content
})

// ui ux
let UiUx=document.getElementById('UiUx')
UiUx.addEventListener('click',function(){
  resetColor()
  cards_trend_content=``
  UiUx.style.backgroundColor='#DBF6E6'
    UiUx.style.color='#0D363B'
    for (let i = 0; i < 3; i++) {
        cards_trend_content+=`
        <div class="cards-trend-card">
        <h1>Ui Ux</h1>
        <p><i class="fas fa-building-flag"></i> اسم الشركة:  <span> المقاولون العرب</span></p>
        <p><i class="fas fa-location-dot"></i> موقع الشركة:  <span>  القاهرة، مدينة نصر</span></p>
        <p><i class="fas fa-money-bill-1-wave"></i> الراتب الاساسي:  <span>  8000 ج/م</span></p>
        <p><i class="fas fa-cubes"></i> نوع الوظيفة:  <span>  يومين عطلة كل اسبوع</span></p>
        <img src="./logo/SVGRepo_iconCarrier.svg" alt="">
        <button>تقديم</button>
        <div class="icons">
          <i class="fas fa-share-nodes"></i>
          <i class="fas fa-bookmark"></i>
        </div>
      
        </div>
    `
        
        
    }
    cards_trend.innerHTML=cards_trend_content
})

// خدمة عملاء
let customerService=document.getElementById('customerService')
customerService.addEventListener('click',function(){
  resetColor()
  cards_trend_content=``
  customerService.style.backgroundColor='#DBF6E6'
    customerService.style.color='#0D363B'
    for (let i = 0; i < 3; i++) {
        cards_trend_content+=`
        <div class="cards-trend-card">
        <h1>خدمة عملاء</h1>
        <p><i class="fas fa-building-flag"></i> اسم الشركة:  <span> المقاولون العرب</span></p>
        <p><i class="fas fa-location-dot"></i> موقع الشركة:  <span>  القاهرة، مدينة نصر</span></p>
        <p><i class="fas fa-money-bill-1-wave"></i> الراتب الاساسي:  <span>  8000 ج/م</span></p>
        <p><i class="fas fa-cubes"></i> نوع الوظيفة:  <span>  يومين عطلة كل اسبوع</span></p>
        <img src="./logo/SVGRepo_iconCarrier.svg" alt="">
        <button>تقديم</button>
        <div class="icons">
          <i class="fas fa-share-nodes"></i>
          <i class="fas fa-bookmark"></i>
        </div>
      
        </div>
    `
        
        
    }
    cards_trend.innerHTML=cards_trend_content
})

// ادارة اعمال
let management=document.getElementById('management')
management.addEventListener('click',function(){
  resetColor()
  cards_trend_content=``
  management.style.backgroundColor='#DBF6E6'
    management.style.color='#0D363B'
    for (let i = 0; i < 3; i++) {
        cards_trend_content+=`
        <div class="cards-trend-card">
        <h1>إدارة اعمال</h1>
        <p><i class="fas fa-building-flag"></i> اسم الشركة:  <span> المقاولون العرب</span></p>
        <p><i class="fas fa-location-dot"></i> موقع الشركة:  <span>  القاهرة، مدينة نصر</span></p>
        <p><i class="fas fa-money-bill-1-wave"></i> الراتب الاساسي:  <span>  8000 ج/م</span></p>
        <p><i class="fas fa-cubes"></i> نوع الوظيفة:  <span>  يومين عطلة كل اسبوع</span></p>
        <img src="./logo/SVGRepo_iconCarrier.svg" alt="">
        <button>تقديم</button>
        <div class="icons">
          <i class="fas fa-share-nodes"></i>
          <i class="fas fa-bookmark"></i>
        </div>
      
        </div>
    `
        
        
    }
    cards_trend.innerHTML=cards_trend_content
})

// iti
let iti=document.getElementById('iti')
iti.addEventListener('click',function(){
  cards_trend_content=``
  resetColor()
  iti.style.backgroundColor='#DBF6E6'
  iti.style.color='#0D363B'
    for (let i = 0; i < 3; i++) {
        cards_trend_content+=`
        <div class="cards-trend-card">
        <h1>iti</h1>
        <p><i class="fas fa-building-flag"></i> اسم الشركة:  <span> المقاولون العرب</span></p>
        <p><i class="fas fa-location-dot"></i> موقع الشركة:  <span>  القاهرة، مدينة نصر</span></p>
        <p><i class="fas fa-money-bill-1-wave"></i> الراتب الاساسي:  <span>  8000 ج/م</span></p>
        <p><i class="fas fa-cubes"></i> نوع الوظيفة:  <span>  يومين عطلة كل اسبوع</span></p>
        <img src="./logo/SVGRepo_iconCarrier.svg" alt="">
        <button>تقديم</button>
        <div class="icons">
          <i class="fas fa-share-nodes"></i>
          <i class="fas fa-bookmark"></i>
        </div>
      
        </div>
    `
        
        
    }
    cards_trend.innerHTML=cards_trend_content
})

// المزيد
let more=document.getElementById('more')
more.addEventListener('click',function(){
  resetColor()
  cards_trend_content=``
  accounting.style.backgroundColor='#DBF6E6'
    accounting.style.color='#0D363B'
    for (let i = 0; i < 3; i++) {
        cards_trend_content+=`
        <div class="cards-trend-card">
        <h1>المزيد</h1>
        <p><i class="fas fa-building-flag"></i> اسم الشركة:  <span> المقاولون العرب</span></p>
        <p><i class="fas fa-location-dot"></i> موقع الشركة:  <span>  القاهرة، مدينة نصر</span></p>
        <p><i class="fas fa-money-bill-1-wave"></i> الراتب الاساسي:  <span>  8000 ج/م</span></p>
        <p><i class="fas fa-cubes"></i> نوع الوظيفة:  <span>  يومين عطلة كل اسبوع</span></p>
        <img src="./logo/SVGRepo_iconCarrier.svg" alt="">
        <button>تقديم</button>
        <div class="icons">
          <i class="fas fa-share-nodes"></i>
          <i class="fas fa-bookmark"></i>
        </div>
      
        </div>
    `
        
        
    }
    cards_trend.innerHTML=cards_trend_content
})




// search for cards
let photo = document.querySelector('.photo');
let button = document.querySelector('.img-b');

button.addEventListener('click', function() {
  photo.classList.toggle('hidden');
});
