const d1 =document.getElementById("d1");
const d2 = document.getElementById("d2");
const next = document.getElementById("next");
next.addEventListener("click",()=>{
    d1.classList.add("hidden");
    d2.classList.remove("hidden");
})
back.addEventListener("click",()=>{
    d2.classList.add("hidden");
    d1.classList.remove("hidden");
})
