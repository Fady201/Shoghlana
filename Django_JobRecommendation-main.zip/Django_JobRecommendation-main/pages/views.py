from django.shortcuts import render

from account.models import User, Company, JobSeeker


def home(request):
    is_auth = False
    user = None
    if request.user is not None and request.user.is_authenticated:
        is_auth = True
        user = User.objects.get(pk=request.user.pk)
        if user.user_type == 'company':
            user = Company.objects.get(user=user)
        elif user.user_type == 'jobSeeker':
            user = JobSeeker.objects.get(user=user)
    return render(request, "home.html", {"is_auth": is_auth, "user": user})


def courses(request):
    return render(request, "pages/courses.html")